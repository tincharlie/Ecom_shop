# from django.contrib import admin
from django.urls import path
from .views.home import Index , store
from .views.login import Login
from .views.signup import Signup
from .views.login import logout
from .views.cart import Cart
from .views.checkout import CheckOut
from .views.orders import OrderView

from store.middlewares.auth import auth_middleware


# from .views import home, login , signup
# urlpatterns = [
#     path('', home.index, name='homepage'),
#     path('signup', signup.Signup.as_view(), name = 'signup'),
#     path('login' , login.Login.as_view(), name = 'login')
# ]

urlpatterns = [
    path('', Index.as_view(), name='homepage'),
    path('store', store , name='store'),
    path('signup', Signup.as_view(), name='signup'),
    path('login', Login.as_view(), name='login'),
    path('logout', logout, name='logout'),
    path('cart', Cart.as_view(), name='cart'),
    path('check-out', CheckOut.as_view(), name='checkout'),
    path('orders', auth_middleware(OrderView.as_view()), name='orders'),

]

